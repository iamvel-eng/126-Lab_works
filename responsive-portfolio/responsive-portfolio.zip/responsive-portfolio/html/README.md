# HTML

HTML (HyperText Markup Language) is a language that is concerned about the layout of elements on a web page.