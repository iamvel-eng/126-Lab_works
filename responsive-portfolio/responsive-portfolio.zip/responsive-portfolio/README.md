<<<<<<< HEAD
# 126-Lab_works
=======
# web-engineering-starter-pack
A starter pack of tutorials for people to get started in web engineering through Django.

# References

1. Web Applications by John Ousterhout. http://www.stanford.edu/~ouster/cgi-bin/cs142-fall10/index.php
2. Web Development by Steve Huffman. https://www.udacity.com/course/cs253
3. Software Engineering for Web Applications by Philip Greenspun. http://ocw.mit.edu/courses/electrical-engineering-and-computer-science/6-171-software-engineering-for-web-applications-fall-2003/index.htm
4. Codecademy. http://www.codecademy.com/


>>>>>>> upstream/main
